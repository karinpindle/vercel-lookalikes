import { createFileRoute } from "@tanstack/react-router";
import { SectionContainer } from "@/components/section-page";

export const Route = createFileRoute("/icp/summary")({
  head: () => ({
    meta: [
      { title: "ICP Summary — Salesforce Agentforce" },
      {
        name: "description",
        content:
          "Digest of the selected Salesforce Agentforce ICP: fit, triggers, signals, buying committee, and displacement targets.",
      },
    ],
  }),
  component: IcpSummary,
});

function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-block rounded border border-border bg-secondary/60 px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
      {children}
    </span>
  );
}

function Card({
  title,
  eyebrow,
  children,
}: {
  title: string;
  eyebrow?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-6">
      {eyebrow ? (
        <div className="mb-1 text-[10px] font-medium uppercase tracking-[0.18em] text-accent">
          {eyebrow}
        </div>
      ) : null}
      <h3 className="font-serif text-lg text-foreground">{title}</h3>
      <div className="mt-3 text-sm text-muted-foreground">{children}</div>
    </div>
  );
}

const triggers = [
  {
    label: "Agent pilot ROI reckoning",
    urgency: "This year",
    text: "Boards want measurable outcomes from 2025 GenAI pilots — consolidation onto one governed agent platform is the natural next move.",
  },
  {
    label: "EU AI Act full application",
    urgency: "This quarter",
    text: "August 2026 kicks in documented governance, logging, and conformity obligations — favors platforms with a built-in trust and audit layer.",
  },
  {
    label: "Microsoft 365 price rise",
    urgency: "This quarter",
    text: "July 2026 price increases and EA discount removal push M365 buyers to re-test whether Copilot Studio justifies its cost vs. a CRM-native alternative.",
  },
  {
    label: "Agentforce momentum",
    urgency: "This year",
    text: "~$800M ARR reported in Q4 FY2026 (up ~169% YoY) makes the CRM-native agent layer the default consolidation target for Salesforce-anchored accounts.",
  },
];

const signals = [
  "Salesforce Data Cloud / Data 360 recently provisioned or expanding",
  "Intent surge: 'AI agents', 'agentic AI', 'Copilot Studio', 'Agentforce'",
  "Hiring: AI/ML, conversational AI, or agent engineers alongside existing SF admins",
  "Multi-cloud Salesforce footprint (Service + Sales + Marketing/Commerce)",
  "Newly named Chief AI Officer, VP of AI, or AI CoE charter",
  "Salesforce EA up for renewal or true-up (bundling moment)",
  "High customer-service case or contact volume; large BPO spend",
  "Regulated-industry account facing EU AI Act or sector AI-governance mandates",
];

const dms = [
  {
    role: "Chief AI Officer / VP of AI",
    priorities: "Speed to value, governance, defensible platform bet",
    message:
      "Consolidate pilots onto a governed platform grounded in the data you already trust.",
  },
  {
    role: "CIO / VP Enterprise Applications",
    priorities: "Fewer platforms, security, reuse of existing investment",
    message:
      "Extend the Salesforce you already run rather than standing up a separate agent stack.",
  },
  {
    role: "VP Customer Service / Contact Center",
    priorities: "Deflection, resolution quality, agent productivity",
    message:
      "Autonomous service agents grounded in your case data cut cost-to-serve without rip-and-replace.",
  },
  {
    role: "Chief Data Officer",
    priorities: "Data quality, governance, residency",
    message:
      "Data 360 grounding + Einstein Trust Layer make outputs governed and auditable by design.",
  },
];

const strong = [
  { name: "Microsoft — Copilot Studio", signal: "M365 E5 / Power Platform standardized, heavy Teams usage" },
  { name: "Google — Gemini Enterprise", signal: "Google Workspace and/or BigQuery as data core" },
  { name: "ServiceNow — Now Assist Agents", signal: "ServiceNow is enterprise workflow backbone; ITSM-led AI budget" },
  { name: "Amazon — Bedrock Agents / Q", signal: "AWS-heavy account with strong platform-engineering team" },
  { name: "OpenAI — Assistants / Agents API", signal: "ChatGPT Enterprise deployed; in-house AI engineering" },
];

const weak = [
  { name: "UiPath — Agentic Automation", signal: "Large RPA base but limited CRM-grounded agent cases" },
  { name: "IBM — watsonx Orchestrate", signal: "IBM-centric enterprise without a Salesforce-grounded path" },
  { name: "SAP — Joule agents", signal: "SAP-anchored account confining agents to ERP processes" },
];

const adjacent = [
  { name: "Sierra", signal: "Consumer brand piloting a standalone support-agent vendor" },
  { name: "Decagon", signal: "High-volume support org trialing best-of-breed support agent" },
  { name: "Ada", signal: "Existing Ada/chatbot deployment up for renewal" },
  { name: "Cognigy", signal: "Voice-heavy contact center on a conversational-AI vendor" },
];

const cross = [
  { b: "Data 360 (Data Cloud)", s: "Single strongest predictor of Agentforce success — grounding layer.", trend: "Growing" },
  { b: "Service Cloud", s: "High case volume → immediate deflection use case.", trend: "Growing" },
  { b: "Sales Cloud", s: "Pipeline & account data enable autonomous sales agents.", trend: "Stable" },
  { b: "Slack", s: "Human-agent interface for invoking and supervising agents.", trend: "Growing" },
  { b: "MuleSoft + Informatica", s: "API connectivity + governed metadata ground agents beyond CRM.", trend: "Growing" },
];

function IcpSummary() {
  return (
    <SectionContainer>
      {/* Hero */}
      <div className="mb-8 rounded-lg border border-border bg-gradient-to-br from-secondary/60 to-card p-8">
        <div className="text-[10px] font-medium uppercase tracking-[0.2em] text-accent">
          Selected proposition · Agentic AI · Governed automation
        </div>
        <h2 className="mt-2 font-serif text-3xl text-foreground">
          Agentforce — Enterprise Agentic AI Platform
        </h2>
        <p className="mt-3 text-sm text-muted-foreground sm:text-base">
          Salesforce's ideal Agentforce buyer is a{" "}
          <span className="text-foreground">large existing Salesforce customer</span> with{" "}
          <span className="text-foreground">Data 360 (or a live CDP)</span>,{" "}
          <span className="text-foreground">high-volume customer interactions</span>, and{" "}
          <span className="text-foreground">board pressure to turn 2025 AI pilots into measured outcomes</span>.
          They're not buying a chatbot — they're buying governed, data-grounded automation of
          customer-facing work with an audit trail.
        </p>

        <div className="mt-6 grid grid-cols-2 gap-4 border-t border-border pt-6 sm:grid-cols-5">
          {[
            { v: "1", l: "Proposition ICP" },
            { v: "4", l: "Decision-maker roles" },
            { v: "12", l: "Competitors ranked" },
            { v: "4", l: "Market triggers" },
            { v: "8", l: "Detectable signals" },
          ].map((s) => (
            <div key={s.l}>
              <div className="font-mono text-2xl font-semibold text-foreground">{s.v}</div>
              <div className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                {s.l}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Firmographic fit */}
      <div className="mb-8 grid gap-4 md:grid-cols-3">
        <Card eyebrow="Firmographic fit" title="Industry">
          High-interaction, data-rich verticals already standardized on Salesforce:
          <div className="mt-3 flex flex-wrap gap-1.5">
            {[
              "Financial services",
              "Telecom",
              "Retail & consumer",
              "Travel & hospitality",
              "Technology",
              "Healthcare & life sciences",
            ].map((t) => (
              <Kbd key={t}>{t}</Kbd>
            ))}
          </div>
        </Card>
        <Card eyebrow="Firmographic fit" title="Size">
          <span className="text-foreground">$1B+ revenue, 5,000+ employees</span> — but the truer
          proxy is interaction volume: case counts, contact-center seats, monthly active customers.
          <div className="mt-3 flex flex-wrap gap-1.5">
            <Kbd>5,000+ employees</Kbd>
            <Kbd>$1B+ revenue</Kbd>
            <Kbd>High case volume</Kbd>
            <Kbd>Millions of end customers</Kbd>
          </div>
        </Card>
        <Card eyebrow="Firmographic fit" title="Geography">
          Concentrated in North America and UK / Western Europe with growth in ANZ and Japan. EU/UK
          adds data-residency and AI-governance requirements.
          <div className="mt-3 flex flex-wrap gap-1.5">
            <Kbd>North America</Kbd>
            <Kbd>UK & W. Europe</Kbd>
            <Kbd>ANZ</Kbd>
            <Kbd>Japan</Kbd>
          </div>
        </Card>
      </div>

      {/* Why now */}
      <div className="mb-8">
        <h3 className="font-serif text-xl text-foreground">Why now — market triggers</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          The forces making an Agentforce conversation land in the next two quarters.
        </p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {triggers.map((t) => (
            <div
              key={t.label}
              className="rounded-lg border border-border bg-card p-5"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="font-medium text-foreground">{t.label}</div>
                <span className="rounded-full border border-accent/30 bg-accent/5 px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider text-accent">
                  {t.urgency}
                </span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{t.text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Detectable signals */}
      <div className="mb-8">
        <h3 className="font-serif text-xl text-foreground">Detectable buying signals</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Observable from the outside using HG technographic, intent, and firmographic data.
        </p>
        <ol className="mt-4 grid gap-2 md:grid-cols-2">
          {signals.map((s, i) => (
            <li
              key={s}
              className="flex gap-3 rounded-md border border-border bg-card px-4 py-3 text-sm"
            >
              <span className="font-mono text-xs text-accent">{String(i + 1).padStart(2, "0")}</span>
              <span className="text-muted-foreground">{s}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* Buying committee */}
      <div className="mb-8">
        <h3 className="font-serif text-xl text-foreground">Buying committee</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          AI-strategy owners set direction; CRM and data owners control feasibility and budget.
        </p>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {dms.map((d) => (
            <div key={d.role} className="rounded-lg border border-border bg-card p-5">
              <div className="font-medium text-foreground">{d.role}</div>
              <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">
                {d.priorities}
              </div>
              <p className="mt-3 border-t border-border pt-3 text-sm italic text-muted-foreground">
                "{d.message}"
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Competitive landscape */}
      <div className="mb-8">
        <h3 className="font-serif text-xl text-foreground">Competitive landscape</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Each competitor's position translates into an observable account signal.
        </p>
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <div className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-destructive" />
              <div className="text-xs font-medium uppercase tracking-wider text-foreground">
                Strong displacement — hard
              </div>
            </div>
            <ul className="mt-3 space-y-3 text-sm">
              {strong.map((c) => (
                <li key={c.name} className="border-t border-border pt-3 first:border-0 first:pt-0">
                  <div className="text-foreground">{c.name}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{c.signal}</div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <div className="text-xs font-medium uppercase tracking-wider text-foreground">
                Weak displacement — easy–moderate
              </div>
            </div>
            <ul className="mt-3 space-y-3 text-sm">
              {weak.map((c) => (
                <li key={c.name} className="border-t border-border pt-3 first:border-0 first:pt-0">
                  <div className="text-foreground">{c.name}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{c.signal}</div>
                </li>
              ))}
            </ul>
          </div>
          <div className="rounded-lg border border-border bg-card p-5">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-accent" />
              <div className="text-xs font-medium uppercase tracking-wider text-foreground">
                Adjacent — service only
              </div>
            </div>
            <ul className="mt-3 space-y-3 text-sm">
              {adjacent.map((c) => (
                <li key={c.name} className="border-t border-border pt-3 first:border-0 first:pt-0">
                  <div className="text-foreground">{c.name}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{c.signal}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Complementary pull */}
      <div className="mb-4">
        <h3 className="font-serif text-xl text-foreground">Complementary Salesforce pull</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          A deep Salesforce + clean-data footprint is what makes Agentforce land.
        </p>
        <div className="mt-4 overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-secondary/50 text-left text-[11px] uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Technology</th>
                <th className="px-4 py-3 font-medium">Why it matters</th>
                <th className="px-4 py-3 font-medium">Trend</th>
              </tr>
            </thead>
            <tbody>
              {cross.map((r, i) => (
                <tr
                  key={r.b}
                  className={i > 0 ? "border-t border-border" : ""}
                >
                  <td className="px-4 py-3 font-medium text-foreground">{r.b}</td>
                  <td className="px-4 py-3 text-muted-foreground">{r.s}</td>
                  <td className="px-4 py-3">
                    <span
                      className={
                        "rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider " +
                        (r.trend === "Growing"
                          ? "bg-emerald-500/10 text-emerald-600"
                          : "bg-secondary text-muted-foreground")
                      }
                    >
                      {r.trend}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <p className="mt-6 border-t border-border pt-4 text-xs text-muted-foreground">
        Source: Salesforce Agentforce ICP framework (rgif-prop-icp 1.3, July 17, 2026). Reformatted
        by HG Insights for this response.
      </p>
    </SectionContainer>
  );
}
