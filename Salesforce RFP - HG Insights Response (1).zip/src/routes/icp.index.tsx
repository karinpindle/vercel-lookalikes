import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/icp/")({
  beforeLoad: () => {
    throw redirect({ to: "/icp/summary" });
  },
});
