import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { SectionContainer } from "@/components/section-page";

export const Route = createFileRoute("/icp/account-brief/")({
  head: () => ({
    meta: [
      { title: "Account Briefs — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "Sample Account Briefs written for a Salesforce AE, with named contacts and opportunity guidance.",
      },
    ],
  }),
  component: AccountBriefIndex,
});

const briefs = [
  {
    slug: "celcom",
    company: "Celcom Berhad (CelcomDigi)",
    tag: "Telecom · Malaysia",
    tier: "Tier A · Rank #1",
    hook:
      "Malaysia's largest mobile operator (20.4M subs) publicly betting on AI-led CX mid-merger. Strong fit, quiet intent — a demand-creation play.",
    focus: [
      "AI Maturity 15 · GenAI Intent 20k",
      "IT Spend $74M · AI Spend $21M",
      "Merger + CX transformation window",
    ],
  },
  {
    slug: "primerica",
    company: "Primerica, Inc.",
    tag: "Insurance · United States",
    tier: "Tier A · Rank #2",
    hook:
      "Middle-income insurance & investments; existing SF CRM, MuleSoft, Tableau footprint. Clear expansion play for licensed-rep enablement with Agentforce.",
    focus: [
      "AI Maturity 19 · GenAI Intent 39k",
      "AI Spend $34M · GenAI $14M",
      "Named contacts + drafted outreach",
    ],
  },
];

function AccountBriefIndex() {
  return (
    <SectionContainer>
      <div className="mb-6">
        <h2 className="font-serif text-2xl text-foreground">Account Briefs</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Sample account briefs written for a Salesforce AE. Each covers Agentforce score
          rationale, firmos, technos, spend, AI maturity, intent, named contacts, drafted
          emails, and the specific opps to win.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-2">
        {briefs.map((b) => (
          <Link
            key={b.slug}
            to="/icp/account-brief/$briefId"
            params={{ briefId: b.slug }}
            className="group flex flex-col rounded-lg border border-border bg-card p-6 transition-all hover:border-accent hover:shadow-md"
          >
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              {b.tag}
            </div>
            <h3 className="mt-2 font-serif text-2xl text-foreground">{b.company}</h3>
            <div className="mt-1 text-xs font-semibold uppercase tracking-wide text-accent">
              {b.tier}
            </div>
            <p className="mt-3 flex-1 text-sm text-muted-foreground">{b.hook}</p>
            <ul className="mt-4 space-y-1.5 border-t border-border pt-4 text-sm text-foreground/80">
              {b.focus.map((f) => (
                <li key={f} className="flex items-center gap-2">
                  <span className="h-1 w-1 rounded-full bg-accent" />
                  {f}
                </li>
              ))}
            </ul>
            <div className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary group-hover:gap-2 transition-all">
              View full brief <ArrowRight className="h-4 w-4" />
            </div>
          </Link>
        ))}
      </div>
    </SectionContainer>
  );
}
