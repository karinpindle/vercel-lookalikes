import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionContainer } from "@/components/section-page";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Account = {
  rank: number;
  company: string;
  hgId: string;
  industry: string;
  country: string;
  sfProducts: string[];
  fit: number;
  need: number;
  intent: number;
  composite: number;
  tier: "A" | "B";
  aiMaturity: number | null;
  dataMaturity: "High" | "Medium" | "Low" | "—";
  genAiIntent: number | null;
  aiSpend: string;
  genAiSpend: string;
  spendBand:
    | "Mega"
    | "Very High"
    | "High"
    | "Elevated"
    | "Moderate"
    | "Emerging";
};

const accounts: Account[] = [
  { rank: 1, company: "Celcom Berhad", hgId: "196F8B6226C944F7E7D424A1E6DD456B", industry: "Telecom", country: "Malaysia", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 76, need: 64, intent: 27, composite: 63, tier: "A", aiMaturity: 15.06, dataMaturity: "Low", genAiIntent: 20445, aiSpend: "$21M", genAiSpend: "$8M", spendBand: "Elevated" },
  { rank: 2, company: "Primerica, Inc.", hgId: "374F58B0A16D66CF43E2160878B26147", industry: "Insurance Brokerage", country: "United States", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 78, need: 49, intent: 52, composite: 61, tier: "A", aiMaturity: 18.74, dataMaturity: "Low", genAiIntent: 39167, aiSpend: "$34M", genAiSpend: "$14M", spendBand: "Elevated" },
  { rank: 3, company: "Essentia Health", hgId: "17DA51869CC57B96D4E2CB26BCF699B1", industry: "Hospitals", country: "United States", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 75, need: 49, intent: 55, composite: 60, tier: "A", aiMaturity: 23.53, dataMaturity: "Low", genAiIntent: 32138, aiSpend: "$52M", genAiSpend: "$20M", spendBand: "High" },
  { rank: 4, company: "PartnerRe Ltd.", hgId: "36DE788FE960A1AFCE2E8DD64F948AA7", industry: "Reinsurance", country: "United States", sfProducts: ["CRM","Pardot","Tableau"], fit: 80, need: 56, intent: 20, composite: 60, tier: "A", aiMaturity: 19.76, dataMaturity: "Low", genAiIntent: 12580, aiSpend: "$93M", genAiSpend: "$38M", spendBand: "High" },
  { rank: 5, company: "National Westminster Bank Public Limited Company", hgId: "19963817FC4628C9ABE9A672E717A1B9", industry: "Commercial Banking", country: "United Kingdom", sfProducts: ["CRM","Pardot","MuleSoft","Tableau"], fit: 85, need: 48, intent: 24, composite: 59, tier: "B", aiMaturity: 31.77, dataMaturity: "Medium", genAiIntent: 12484, aiSpend: "$193M", genAiSpend: "$73M", spendBand: "Very High" },
  { rank: 6, company: "Al Ghurair Investment (L.L.C.)", hgId: "37C2D7D8D39EFD79AE3F615CADE786D9", industry: "Financial Investment", country: "United Arab Emirates", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 81, need: 58, intent: 4, composite: 59, tier: "B", aiMaturity: 30.79, dataMaturity: "Low", genAiIntent: 2476, aiSpend: "$37M", genAiSpend: "$14M", spendBand: "Elevated" },
  { rank: 7, company: "Sumitomo Mitsui Trust Bank, Limited", hgId: "174CB24A1B4F89E8E1122597B0235AB1", industry: "Commercial Banking", country: "Japan", sfProducts: ["CRM"], fit: 88, need: 48, intent: 8, composite: 58, tier: "B", aiMaturity: 17.42, dataMaturity: "Low", genAiIntent: 2230, aiSpend: "$69M", genAiSpend: "$26M", spendBand: "High" },
  { rank: 8, company: "Sumitomo Mitsui Banking Corporation", hgId: "24A5E8B8B8C50AC3909E97F016D2CDF5", industry: "Commercial Banking", country: "Japan", sfProducts: ["CRM","Pardot","Tableau"], fit: 82, need: 52, intent: 9, composite: 58, tier: "B", aiMaturity: 26.51, dataMaturity: "Medium", genAiIntent: 3779, aiSpend: "$8M", genAiSpend: "$3M", spendBand: "Moderate" },
  { rank: 9, company: "EFG International AG", hgId: "1C19A035A50325746CBF6629450AA4B5", industry: "Commercial Banking", country: "Switzerland", sfProducts: ["CRM","Pardot","MuleSoft","Tableau"], fit: 82, need: 56, intent: 0, composite: 58, tier: "B", aiMaturity: 21.19, dataMaturity: "Low", genAiIntent: 133, aiSpend: "$22M", genAiSpend: "$8M", spendBand: "Elevated" },
  { rank: 10, company: "Skipton Building Society", hgId: "1BE3CA3721D1146C54B54CA120F43E77", industry: "Savings Institution", country: "United Kingdom", sfProducts: ["CRM","Pardot","Tableau"], fit: 87, need: 48, intent: 0, composite: 56, tier: "B", aiMaturity: null, dataMaturity: "—", genAiIntent: null, aiSpend: "$14M", genAiSpend: "$5M", spendBand: "Moderate" },
  { rank: 11, company: "INTESA SANPAOLO ASSICURAZIONI S.p.A", hgId: "1D3CE96FBEF1C2ED26B8BA93EFCA1E6E", industry: "Life Insurance", country: "Italy", sfProducts: ["CRM","CRM Analytics","Tableau"], fit: 82, need: 40, intent: 33, composite: 56, tier: "B", aiMaturity: 26.51, dataMaturity: "Low", genAiIntent: 12118, aiSpend: "$88M", genAiSpend: "$35M", spendBand: "High" },
  { rank: 12, company: "Hong Kong Exchanges And Clearing Limited", hgId: "1826B0FB7660075418917947EC6AD660", industry: "Exchanges", country: "Hong Kong", sfProducts: ["CRM","Pardot","MuleSoft","Tableau"], fit: 80, need: 51, intent: 5, composite: 56, tier: "B", aiMaturity: 21.67, dataMaturity: "Low", genAiIntent: 1308, aiSpend: "$30M", genAiSpend: "$11M", spendBand: "Elevated" },
  { rank: 13, company: "Spire Healthcare Group Plc", hgId: "3CDE73F8B9880A47E86326AB42DA2EFC", industry: "Hospitals", country: "United Kingdom", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 74, need: 51, intent: 8, composite: 54, tier: "B", aiMaturity: 16.15, dataMaturity: "Low", genAiIntent: 5675, aiSpend: "$41M", genAiSpend: "$15M", spendBand: "Elevated" },
  { rank: 14, company: "Raiffeisenbankengruppe OÖ Verbund eGen", hgId: "3D31EB36BE67EB0137F7A3E481BA3388", industry: "Commercial Banking", country: "Austria", sfProducts: ["CRM","Tableau"], fit: 80, need: 49, intent: 0, composite: 54, tier: "B", aiMaturity: null, dataMaturity: "—", genAiIntent: null, aiSpend: "$31M", genAiSpend: "$12M", spendBand: "Elevated" },
  { rank: 15, company: "Alfred Health", hgId: "3AF93E53D1EE55F661D3717E930A7083", industry: "Hospitals", country: "Australia", sfProducts: ["CRM","Pardot","Tableau"], fit: 72, need: 51, intent: 18, composite: 54, tier: "B", aiMaturity: 21.57, dataMaturity: "Low", genAiIntent: 1084, aiSpend: "$20M", genAiSpend: "$8M", spendBand: "Elevated" },
  { rank: 16, company: "Grupo Security S.A.", hgId: "387FD1DB51F0A18B705F128FC3A338D0", industry: "Commercial Banking", country: "Chile", sfProducts: ["CRM","Tableau"], fit: 78, need: 48, intent: 11, composite: 54, tier: "B", aiMaturity: 16.43, dataMaturity: "Low", genAiIntent: 1871, aiSpend: "$28M", genAiSpend: "$11M", spendBand: "Elevated" },
  { rank: 17, company: "Ntt Data Corporation", hgId: "31A3662BCAE7EC043BA9763891F6B5FD", industry: "IT Services", country: "Japan", sfProducts: ["CRM","Pardot","Tableau"], fit: 75, need: 35, intent: 46, composite: 53, tier: "B", aiMaturity: 13.93, dataMaturity: "Low", genAiIntent: 34276, aiSpend: "$363M", genAiSpend: "$132M", spendBand: "Mega" },
  { rank: 18, company: "Uk Healthcare", hgId: "18A6D10C39E0A0CD6E6E02D9CDAD0232", industry: "Hospitals", country: "United States", sfProducts: ["CRM","Tableau"], fit: 72, need: 42, intent: 34, composite: 53, tier: "B", aiMaturity: 17.68, dataMaturity: "Low", genAiIntent: 17358, aiSpend: "$68M", genAiSpend: "$26M", spendBand: "High" },
  { rank: 19, company: "Converge Technology Solutions Corp", hgId: "3FC6190E2D165FF7AFDFC88C2D22F46C", industry: "IT Services", country: "Canada", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 70, need: 42, intent: 32, composite: 52, tier: "B", aiMaturity: 27.19, dataMaturity: "Low", genAiIntent: 17268, aiSpend: "$23M", genAiSpend: "$8M", spendBand: "Elevated" },
  { rank: 20, company: "Cathay General Bancorp", hgId: "32412227BD197F13BC7BE796A5932E69", industry: "Commercial Banking", country: "United States", sfProducts: ["CRM","MuleSoft","Tableau"], fit: 65, need: 49, intent: 28, composite: 52, tier: "B", aiMaturity: 14.91, dataMaturity: "Low", genAiIntent: 20275, aiSpend: "$9M", genAiSpend: "$3M", spendBand: "Moderate" },
];

const tierClass: Record<string, string> = {
  A: "bg-[oklch(0.42_0.14_150)] text-white",
  B: "bg-[oklch(0.55_0.15_255)] text-white",
};

const bandClass: Record<string, string> = {
  Mega: "bg-[oklch(0.2_0.06_260)] text-white",
  "Very High": "bg-[oklch(0.45_0.18_265)] text-white",
  High: "bg-[oklch(0.88_0.08_260)] text-[oklch(0.3_0.12_265)]",
  Elevated: "bg-[oklch(0.9_0.06_180)] text-[oklch(0.4_0.09_190)]",
  Moderate: "bg-[oklch(0.94_0.02_260)] text-[oklch(0.45_0.03_260)]",
  Emerging: "bg-[oklch(0.97_0.01_260)] text-muted-foreground",
};

const dmClass: Record<string, string> = {
  High: "text-[oklch(0.5_0.14_150)]",
  Medium: "text-[oklch(0.55_0.14_75)]",
  Low: "text-muted-foreground",
  "—": "text-muted-foreground",
};

export const Route = createFileRoute("/icp/scored-accounts")({
  head: () => ({
    meta: [
      { title: "Top 20 Priority Accounts — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "20 net-new Agentforce expansion accounts — existing Salesforce customers not yet running Agentforce — scored on Fit · Need · Intent (v29) and enriched with HG AI-maturity and AI-spend signals.",
      },
    ],
  }),
  component: ScoredAccounts,
});

function ScoredAccounts() {
  const [q, setQ] = useState("");
  const [tier, setTier] = useState("all");
  const [industry, setIndustry] = useState("all");

  const industries = useMemo(
    () => Array.from(new Set(accounts.map((a) => a.industry))).sort(),
    [],
  );

  const filtered = useMemo(() => {
    return accounts.filter((a) => {
      if (tier !== "all" && a.tier !== tier) return false;
      if (industry !== "all" && a.industry !== industry) return false;
      if (q) {
        const s = q.toLowerCase();
        if (!a.company.toLowerCase().includes(s)) return false;
      }
      return true;
    });
  }, [q, tier, industry]);

  const aTier = accounts.filter((a) => a.tier === "A").length;
  const bTier = accounts.filter((a) => a.tier === "B").length;
  const maturityVals = accounts.map((a) => a.aiMaturity).filter((v): v is number => v != null);
  const avgMaturity = Math.round(
    maturityVals.reduce((s, v) => s + v, 0) / maturityVals.length,
  );

  return (
    <SectionContainer>
      <div className="mb-6">
        <h2 className="font-serif text-2xl text-foreground">
          Sample of Scored Accounts for Agentforce
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          20 expansion accounts from the list of accounts you have us. All are
          existing Salesforce customers{" "}
          <span className="font-semibold text-foreground">
            not yet running Agentforce
          </span>{" "}
          scored by the Fit · Need · Intent model and enriched with HG
          AI-maturity, AI-spend, and current Salesforce-footprint signals.
        </p>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-5">
        <Kpi label="Priority accounts" value="20" note="Curated best-fit sample" accent="primary" />
        <Kpi label="A-tier" value={String(aTier)} note="Composite ≥ 60" accent="chart-1" />
        <Kpi label="B-tier" value={String(bTier)} note="Composite 45–59" accent="chart-3" />
        <Kpi label="Avg AI Maturity" value={String(avgMaturity)} note="HG composite, 0–100" accent="chart-3" />
        <Kpi label="Combined AI Spend" value="$1.2B" note="$470M generative-AI" accent="accent" />
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Input
          placeholder="Search company…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="h-9 max-w-xs"
        />
        <Select value={tier} onValueChange={setTier}>
          <SelectTrigger className="h-9 w-[140px]">
            <SelectValue placeholder="Tier" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All tiers</SelectItem>
            <SelectItem value="A">A</SelectItem>
            <SelectItem value="B">B</SelectItem>
          </SelectContent>
        </Select>
        <Select value={industry} onValueChange={setIndustry}>
          <SelectTrigger className="h-9 w-[260px]">
            <SelectValue placeholder="Industry" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All industries</SelectItem>
            {industries.map((i) => (
              <SelectItem key={i} value={i}>
                {i}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="ml-auto text-xs text-muted-foreground">
          {filtered.length} shown
        </span>
      </div>

      <div className="mb-4 overflow-hidden rounded-lg border border-border bg-secondary/40">
        <div className="border-b border-border bg-secondary px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-secondary-foreground">
          HG AI Maturity signal definitions
        </div>
        <table className="w-full border-collapse text-[12px]">
          <thead>
            <tr className="text-left text-[10.5px] uppercase tracking-wide text-muted-foreground">
              <th className="border-b border-border px-3 py-1.5 font-semibold">Signal</th>
              <th className="border-b border-border px-3 py-1.5 font-semibold">Question it answers</th>
              <th className="border-b border-border px-3 py-1.5 font-semibold">Source</th>
              <th className="border-b border-border px-3 py-1.5 font-semibold">Scale</th>
            </tr>
          </thead>
          <tbody className="text-foreground/85">
            <tr>
              <td className="px-3 py-1.5 font-semibold text-foreground">Data Maturity</td>
              <td className="px-3 py-1.5">Are the data foundations for AI in place?</td>
              <td className="px-3 py-1.5">Detected data tech install base</td>
              <td className="px-3 py-1.5 tabular-nums">0–100 → LOW / MED / HIGH</td>
            </tr>
            <tr className="bg-background/40">
              <td className="px-3 py-1.5 font-semibold text-foreground">GenAI Intent</td>
              <td className="px-3 py-1.5">Are they actively researching / buying GenAI now?</td>
              <td className="px-3 py-1.5">HG intent (research / content signals)</td>
              <td className="px-3 py-1.5">Integer intensity (relative)</td>
            </tr>
            <tr>
              <td className="px-3 py-1.5 font-semibold text-foreground">AI Maturity Score</td>
              <td className="px-3 py-1.5">Overall: how AI-advanced are they?</td>
              <td className="px-3 py-1.5">Composite (incl. data maturity + AI product use)</td>
              <td className="px-3 py-1.5 tabular-nums">0–100</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="overflow-hidden rounded-lg border border-border bg-card shadow-sm">
        <div>
          <table className="w-full table-fixed border-collapse text-[11.5px]">
            <colgroup>
              <col style={{ width: "2.2%" }} />
              <col style={{ width: "16%" }} />
              <col style={{ width: "9%" }} />
              <col style={{ width: "7%" }} />
              <col style={{ width: "11%" }} />
              <col style={{ width: "3.6%" }} />
              <col style={{ width: "3.6%" }} />
              <col style={{ width: "3.6%" }} />
              <col style={{ width: "4.2%" }} />
              <col style={{ width: "3.6%" }} />
              <col style={{ width: "5.4%" }} />
              <col style={{ width: "5%" }} />
              <col style={{ width: "6%" }} />
              <col style={{ width: "5.2%" }} />
              <col style={{ width: "4.6%" }} />
              <col style={{ width: "6.5%" }} />
            </colgroup>
            <thead>
              <tr>
                <GroupTh colSpan={5} className="bg-primary/90">Account</GroupTh>
                <GroupTh colSpan={5} className="bg-primary">Salesforce Agentforce Scoring</GroupTh>
                <GroupTh colSpan={3} className="bg-[oklch(0.5_0.13_150)]">HG GenAI / AI Maturity</GroupTh>
                <GroupTh colSpan={3} className="bg-accent">HG Estimated AI Spend (annual)</GroupTh>
              </tr>
              <tr className="bg-secondary text-[10px] uppercase tracking-wide text-secondary-foreground">
                {["#","Company","Industry","Country","SF Products (current)","Fit","Need","Intent","Comp.","Tier","AI Mat.","Data Mat.","GenAI Intent","AI Spend","GenAI","Band"].map((h) => (
                  <th key={h} className="border-b border-border px-1.5 py-2 font-semibold leading-tight">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((a, idx) => (
                <tr
                  key={a.hgId}
                  className={idx % 2 === 1 ? "bg-secondary/30" : ""}
                >
                  <td className="px-1.5 py-2 text-center tabular-nums text-muted-foreground">
                    {a.rank}
                  </td>
                  <td className="px-1.5 py-2 text-left">
                    <div className="font-semibold text-foreground leading-tight">{a.company}</div>
                    {(a.company === "Primerica, Inc." || a.company === "Celcom Berhad") && (
                      <Link
                        to="/icp/account-brief/$briefId"
                        params={{ briefId: a.company === "Primerica, Inc." ? "primerica" : "celcom" }}
                        className="mt-1 inline-flex items-center rounded border border-primary/40 bg-primary/10 px-1.5 py-0.5 text-[9.5px] font-semibold uppercase tracking-wide text-primary hover:bg-primary hover:text-primary-foreground"
                      >
                        VIEW ACCOUNT BRIEF →
                      </Link>
                    )}
                  </td>
                  <td className="px-1.5 py-2 text-left text-foreground/80 leading-tight">{a.industry}</td>
                  <td className="px-1.5 py-2 text-foreground/80 leading-tight">{a.country}</td>
                  <td className="px-2 py-2 text-left">
                    <div className="flex flex-wrap gap-0.5">
                      {a.sfProducts.map((p) => (
                        <span
                          key={p}
                          className="rounded border border-border bg-secondary px-1 py-0.5 text-[9.5px] font-semibold text-secondary-foreground"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-1 py-2 text-center tabular-nums">{a.fit}</td>
                  <td className="px-1 py-2 text-center tabular-nums">{a.need}</td>
                  <td className="px-1 py-2 text-center tabular-nums">{a.intent}</td>
                  <td className="px-1 py-2 text-center font-bold text-primary tabular-nums">{a.composite}</td>
                  <td className="px-1 py-2 text-center">
                    <span className={`inline-block min-w-5 rounded px-1.5 py-0.5 text-[11px] font-bold ${tierClass[a.tier] ?? "bg-muted"}`}>
                      {a.tier}
                    </span>
                  </td>
                  <td className="px-1 py-2 text-center tabular-nums">
                    {a.aiMaturity != null ? a.aiMaturity.toFixed(1) : <span className="italic text-muted-foreground">—</span>}
                  </td>
                  <td className={`px-1 py-2 text-center text-[10.5px] font-semibold ${dmClass[a.dataMaturity] ?? "text-muted-foreground"}`}>
                    {a.dataMaturity}
                  </td>
                  <td className="px-1 py-2 text-center tabular-nums text-foreground/80">
                    {a.genAiIntent != null ? a.genAiIntent.toLocaleString() : "—"}
                  </td>
                  <td className="px-1 py-2 text-center font-semibold tabular-nums">{a.aiSpend}</td>
                  <td className="px-1 py-2 text-center tabular-nums text-muted-foreground">{a.genAiSpend}</td>
                  <td className="px-1 py-2 text-center">
                    <span className={`inline-block whitespace-nowrap rounded-full px-1.5 py-0.5 text-[9.5px] font-bold ${bandClass[a.spendBand] ?? "bg-muted text-muted-foreground"}`}>
                      {a.spendBand}
                    </span>
                  </td>
                </tr>

              ))}
            </tbody>
          </table>
        </div>
      </div>

    </SectionContainer>
  );
}

function Kpi({
  label,
  value,
  note,
  accent,
}: {
  label: string;
  value: string;
  note: string;
  accent: "primary" | "accent" | "chart-1" | "chart-3";
}) {
  const bar =
    accent === "primary"
      ? "bg-primary"
      : accent === "accent"
        ? "bg-accent"
        : accent === "chart-1"
          ? "bg-[oklch(0.5_0.14_150)]"
          : "bg-[oklch(0.62_0.1_220)]";
  return (
    <div className="overflow-hidden rounded-lg border border-border bg-card shadow-sm">
      <div className={`h-1 ${bar}`} />
      <div className="p-4">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="mt-1 font-serif text-3xl text-primary">{value}</div>
        <div className="mt-1 text-[11px] text-muted-foreground">{note}</div>
      </div>
    </div>
  );
}

function GroupTh({
  children,
  colSpan,
  className,
}: {
  children: React.ReactNode;
  colSpan: number;
  className: string;
}) {
  return (
    <th
      colSpan={colSpan}
      className={`border-r border-white/40 px-2 py-2 text-center text-[11px] font-semibold uppercase tracking-wider text-white ${className}`}
    >
      {children}
    </th>
  );
}
