import { createFileRoute } from "@tanstack/react-router";
import { SectionContainer } from "@/components/section-page";
import { FileText, ExternalLink } from "lucide-react";


export const Route = createFileRoute("/rfp-response/")({
  head: () => ({
    meta: [{ title: "RFP Response — Overview" }],
  }),
  component: RfpOverview,
});

type MatchRow = { label: string; value: string; tone: "good" | "mid" | "bad" };

const deliverables: {
  label: string;
  count: string;
  summary: string;
  headline?: { value: string; caption: string };
  matches?: MatchRow[];
  extras?: { value: string; caption: string };
  fileBreakdown?: {
    primary: { label: string; value: string; note?: string; tone?: "blue" | "violet"; children?: { label: string; value: string; note?: string }[] }[];
    supplementaryLabel: string;
    supplementaryNote?: string;
    supplementary: { label: string; value: string; note?: string }[];
  };

  fileUrl: string;
  fileLabel: string;
}[] = [

  {
    label: "Enriched Accounts",
    count: "~50,000 accounts requested",
    summary:
      "Salesforce's provided account list enriched with HG firmographics, technographics, and intent signals. Delivered as a structured file with standardized fields for company identity, size, industry, technology install base, and intent activity.",
    headline: { value: "96%", caption: "48,242 accounts matched to HG's company graph" },
    fileBreakdown: {
      primary: [
        {
          label: "Technology Installs",
          value: "720,446 installs",
          tone: "blue",
          children: [
            { label: "Installs' Time Series", value: "86M+rows" },
            { label: "Functional Area Intelligence (Buying Centers)", value: "3M rows" },
          ],
        },
        {
          label: "Intent",
      value: "54M+ rows",
      tone: "violet",
      note: 'We provided a file with all intent (54M+ rows) and a file with only "high" intent (14M+ rows)',
          children: [
            { label: "Technology Mentions", value: "34,236 rows" },
          ],
        },

      ],
      supplementaryLabel: "Supplementary HG Data Files",
      supplementaryNote: "Data points not mentioned by HG in our prior RFP response but that support your accounts data coverage and accuracy needs.",
      supplementary: [
        { label: "Generative AI Maturity", value: "15,973\u00a0rows" },
        { label: "Cloud Maturity", value: "47,881 rows" },
        { label: "Spend", value: "47,881 rows" },
        { label: "AI Spend", value: "38,107 rows" },
      ],
    },
    fileUrl: "https://hgdata-my.sharepoint.com/:f:/g/personal/karin_pindle_hginsights_com/IgAqo7fLAy-uRpSzkk2DENuYAZ4fSMwxVwUXiWPGMK4CiL0?e=rHKuiX",
    fileLabel: "View enriched accounts files",
  },

  {
    label: "Technologies Taxonomy Crosswalk",
    count: "2,400 products requested",
    summary:
      "Line-by-line mapping of Salesforce's requested technologies to HG's Technographics catalog, with recommended additions where HG coverage extends beyond the original request.",
    fileBreakdown: {
      primary: [],
      supplementaryLabel: "Supplementary Data Insights",
      supplementaryNote: "Data points not mentioned in our prior RFP response but that support your accounts data coverage and accuracy needs.",
      supplementary: [],
    },
    matches: [
      { label: "Exact match = 2,222", value: "90%", tone: "good" },
      { label: "Partial or approximate = 58", value: "3%", tone: "mid" },
      { label: "No match = 177", value: "7%", tone: "bad" },
    ],
    extras: { value: "8,294", caption: "Additional recommended products from HG's catalog" },
    fileUrl: "https://hgdata-my.sharepoint.com/:x:/g/personal/karin_pindle_hginsights_com/IQBO-1mdhI0BTpACZc1sflrRAWJSYSOEAej17FRchM40W88?e=NRox00",

    fileLabel: "View technologies crosswalk",
  },
  {

    label: "Intent Topics Crosswalk",
    count: "8,000 intent keywords requested",
    summary:
      "Line-by-line mapping of Salesforce's requested intent keywords mapped to HG's Contextual Intent catalog, with recommended expansions and the reasoning behind each addition.",
    fileBreakdown: {
      primary: [],
      supplementaryLabel: "Supplementary Data Insights",
      supplementaryNote: "Data points not mentioned in our prior RFP response but that support your accounts data coverage and accuracy needs.",
      supplementary: [],
    },
    matches: [
      { label: "Exact match = 2,053", value: "26%", tone: "good" },
      { label: "Partial or approximate = 3,892", value: "48%", tone: "mid" },
      { label: "No match = 2,055", value: "26%", tone: "bad" },
    ],
    extras: {
      value: "1,031",
      caption: "Additional recommended topics from HG's Intent catalog (not TrustRadius Buyer Intent)",
    },
    fileUrl: "https://hgdata-my.sharepoint.com/:x:/g/personal/karin_pindle_hginsights_com/IQAet2KC1mHBR4MHyUCEGDYkAYrsbtk26TfCwyXjql_1l6A?e=y2ulFG",

    fileLabel: "View intent crosswalk",
  },

];

const toneClasses: Record<MatchRow["tone"], string> = {
  good: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border-emerald-500/20",
  mid: "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20",
  bad: "bg-rose-500/10 text-rose-700 dark:text-rose-400 border-rose-500/20",
};

function RfpOverview() {
  return (
    <SectionContainer>

      <div className="grid gap-6 md:grid-cols-3">
        {deliverables.map((d) => (
          <div key={d.label} className="flex flex-col rounded-lg border border-border bg-card p-6">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
              <FileText className="h-3.5 w-3.5" />
              {d.count}
            </div>
            <h3 className="mt-2 font-serif text-xl text-foreground">{d.label}</h3>
            <p className="mt-3 text-sm text-muted-foreground">{d.summary}</p>

            {d.headline && (
              <div className="mt-5 rounded-md border border-border bg-muted/30 p-4">
                <div className="font-serif text-3xl text-foreground">{d.headline.value}</div>
                <div className="mt-1 text-xs text-muted-foreground">{d.headline.caption}</div>
              </div>
            )}

            {d.fileBreakdown && (
              <div className="mt-5">
                {d.fileBreakdown.primary.length > 0 && (
                  <div className="mb-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    Files Included
                  </div>
                )}
                <ul className="space-y-2 text-sm">
                  {d.fileBreakdown.primary.map((f) => {
                    const toneStyles =
                      f.tone === "blue"
                        ? {
                            parent: "border-sky-500/40 bg-sky-500/10",
                            branch: "border-sky-500/40",
                            connector: "bg-sky-500/40",
                            child: "border-sky-500/30 bg-sky-500/5",
                          }
                        : f.tone === "violet"
                        ? {
                            parent: "border-violet-500/40 bg-violet-500/10",
                            branch: "border-violet-500/40",
                            connector: "bg-violet-500/40",
                            child: "border-violet-500/30 bg-violet-500/5",
                          }
                        : {
                            parent: "border-border bg-muted/30",
                            branch: "border-border",
                            connector: "bg-border",
                            child: "border-border bg-muted/20",
                          };
                    return (
                      <li key={f.label} className="space-y-2">
                        <div className={`rounded-md border p-3 ${toneStyles.parent}`}>
                          <div className="flex items-baseline justify-between gap-3">
                            <span className="text-foreground">{f.label}</span>
                            <span className="font-serif text-base tabular-nums text-foreground">{f.value}</span>
                          </div>
                          {f.note && <div className="mt-1 text-xs text-muted-foreground">{f.note}</div>}
                        </div>
                        {f.children && f.children.length > 0 && (
                          <ul className={`ml-4 space-y-2 border-l pl-4 ${toneStyles.branch}`}>
                            {f.children.map((c) => (
                              <li key={c.label} className={`relative rounded-md border p-3 ${toneStyles.child}`}>
                                <span
                                  aria-hidden
                                  className={`absolute -left-4 top-1/2 h-px w-4 ${toneStyles.connector}`}
                                />
                                <div className="flex items-baseline justify-between gap-3">
                                  <span className="text-foreground">{c.label}</span>
                                  <span className="font-serif text-sm tabular-nums text-foreground">{c.value}</span>
                                </div>
                                {c.note && <div className="mt-1 text-xs text-muted-foreground">{c.note}</div>}
                              </li>
                            ))}
                          </ul>
                        )}
                      </li>
                    );
                  })}

                </ul>

                {d.fileBreakdown.supplementary.length > 0 && (
                  <>
                    <div className="mt-4 mb-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                      {d.fileBreakdown.supplementaryLabel}
                    </div>
                    {d.fileBreakdown.supplementaryNote && (
                      <div className="mb-2 text-xs italic text-muted-foreground">
                        {d.fileBreakdown.supplementaryNote}
                      </div>
                    )}
                    <ul className="space-y-2 text-sm">
                      {d.fileBreakdown.supplementary.map((f) => (
                        <li key={f.label} className="rounded-md border border-dashed border-border p-3">
                          <div className="flex items-baseline justify-between gap-3">
                            <span className="text-muted-foreground">{f.label}</span>
                            <span className="font-serif text-sm tabular-nums text-foreground">{f.value}</span>
                          </div>
                          {f.note && <div className="mt-1 text-xs text-muted-foreground">{f.note}</div>}
                        </li>
                      ))}
                    </ul>
                  </>
                )}

              </div>
            )}

            {d.matches && (
              <div className="mt-5">
                <div className="mb-2 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                  Match Results
                </div>
                <div className="flex h-2 w-full overflow-hidden rounded-full border border-border">
                  {d.matches.map((m) => (
                    <div
                      key={m.label}
                      className={
                        m.tone === "good"
                          ? "bg-emerald-500"
                          : m.tone === "mid"
                          ? "bg-amber-400"
                          : "bg-rose-500"
                      }
                      style={{ width: m.value }}
                      title={`${m.label}: ${m.value}`}
                    />
                  ))}
                </div>
                <ul className="mt-3 space-y-1.5 text-sm">
                  {d.matches.map((m) => (
                    <li key={m.label} className="flex items-center justify-between gap-3">
                      <span className="text-muted-foreground">{m.label}</span>
                      <span
                        className={`inline-flex min-w-[3rem] justify-center rounded-md border px-2 py-0.5 text-xs font-medium tabular-nums ${toneClasses[m.tone]}`}
                      >
                        {m.value}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {d.extras && (
              <div className="mt-5 rounded-md border border-dashed border-accent/40 bg-accent/5 p-4">
                <div className="font-serif text-2xl text-foreground">+{d.extras.value}</div>
                <div className="mt-1 text-xs text-muted-foreground">{d.extras.caption}</div>
              </div>
            )}

            <div className="mt-6 flex-1" />
            <a
              href={d.fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-md border border-primary bg-primary px-4 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <ExternalLink className="h-4 w-4" />
              {d.fileLabel}
            </a>
          </div>

        ))}
      </div>

      <div className="mt-12">
        <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          ACCOUNTS MATCH NOTES
        </div>
        <h2 className="font-serif text-2xl text-foreground">Why 4% of accounts didn't match</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          HG's focus is on account matching accuracy. We matched 96% of the ~50k accounts Salesforce provided to our company graph. Majority of the remaining 4% fell into one of two buckets:
        </p>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          <li className="rounded-lg border border-border bg-card p-4">
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Reason 1</div>
            <div className="mt-1 font-medium text-foreground">No URL provided & no account name match possible</div>
            <p className="mt-1 text-sm text-muted-foreground">
              No website URL was supplied and HG could not confidently match to the account by name alone.
            </p>
          </li>
          <li className="rounded-lg border border-border bg-card p-4">
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Reason 2</div>
            <div className="mt-1 font-medium text-foreground">Account not in HG's database</div>
            <p className="mt-1 text-sm text-muted-foreground">
              A URL was present but the corresponding company is not currently in HG's database.
            </p>
          </li>
        </ul>
      </div>

      <div className="mt-12">
        <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          Reference
        </div>
        <h2 className="font-serif text-2xl text-foreground">Data Definitions</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Definitions for each HG Insights data point referenced above, sourced from the HG Insights RGIF Data Dictionary.
        </p>
        <div className="mt-4 overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/40">
              <tr className="text-left">
                <th className="w-64 px-4 py-3 font-medium text-foreground">Data Point</th>
                <th className="px-4 py-3 font-medium text-foreground">Definition</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                {
                  term: "Technology Installs",
                  def: "Provides a view into what technology products are in use within an organization. Delivery also includes firmographics.",
                },
                {
                  term: "Installs' Time Series",
                  def: "Timestamped and stored install records for every company and attribute, preserving full change history.",
                },
                {
                  term: "Functional Area Intelligence (Buying Centers)",
                  def: "Based on install detections, tracks which roles and departments within organizations are using technologies and at which locations.",
                },
                {
                  term: "Intent (Buyer Intent)",
                  def: "Differentiated intent data based on real buyer activities on trustradius.com. NOT included in this RFP response.",
                },
                {
                  term: "Intent",
                  def: "Intent data with a layer of contextual enrichment to further illuminate intent signals, comparing the intent against known technology installs and classifying the context of the signal.",
                },
                {
                  term: "Technology Mentions",
                  def: "Tracks key technology transformation themes, with a specific focus on AI adoption.",
                },
                {
                  term: "Generative AI Maturity (GenAI Navigator)",
                  def: "HG scores companies based on their AI product adoption, locations, strength of where the adoption is detected, and the application of an ICP of data-related product detections.",
                },
                {
                  term: "Spend (IT Spend)",
                  def: "A 12-month forward-looking estimate at a company level. Available in two methodologies: IT Spend Absolute and IT Spend Relative.",
                },
                {
                  term: "AI Spend",
                  def: "A 12-month forward-looking estimate of a company's IT budget that is spent on Artificial Intelligence products and services from external vendors.",
                },
                {
                  term: "Cloud Maturity",
                  def: "Company-level assessment of cloud adoption derived from detected cloud platform, infrastructure, and service installs across the organization.",
                },
              ].map((r) => (
                <tr key={r.term} className="bg-card">
                  <td className="px-4 py-3 align-top font-medium text-foreground">{r.term}</td>
                  <td className="px-4 py-3 align-top text-muted-foreground">{r.def}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Source: HG Insights RGIF Data Dictionary.
        </p>
      </div>
    </SectionContainer>
  );
}
