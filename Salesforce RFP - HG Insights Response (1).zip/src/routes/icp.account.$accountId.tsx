import { createFileRoute, Link } from "@tanstack/react-router";
import { SectionContainer, ComingSoon } from "@/components/section-page";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/icp/account/$accountId")({
  head: ({ params }) => ({
    meta: [
      { title: `Account Brief — ${params.accountId}` },
      {
        name: "description",
        content: `HG Insights account brief for ${params.accountId}: score breakdown, tech footprint, intent, and recommended plays.`,
      },
    ],
  }),
  component: AccountBrief,
});

function AccountBrief() {
  const { accountId } = Route.useParams();
  return (
    <SectionContainer>
      <Link
        to="/icp"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Back to scored accounts
      </Link>
      <div className="mt-4 mb-6">
        <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          Account Brief
        </div>
        <h2 className="mt-1 font-serif text-3xl text-foreground">{accountId}</h2>
      </div>
      <ComingSoon note="Firmographics, score breakdown, tech footprint, intent, contacts, and recommended plays will render here once brief data is provided." />
    </SectionContainer>
  );
}
