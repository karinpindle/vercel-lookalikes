import { createFileRoute } from "@tanstack/react-router";
import { SectionContainer } from "@/components/section-page";

export const Route = createFileRoute("/icp/methodology")({
  head: () => ({
    meta: [
      { title: "Scoring Model Summary — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "Fit / Need / Intent scoring model for Salesforce Agentforce expansion — pillars, dimensions, membership gates, tier cutoffs, and HG data sources.",
      },
    ],
  }),
  component: Methodology,
});

const stats = [
  { n: "3", label: "Scoring pillars" },
  { n: "12", label: "Dimensions" },
  { n: "2", label: "Membership gates (audience layer)" },
  { n: "−30", label: "Net-new guard on any Agentforce SKU" },
  { n: "18", label: "Intent topics" },
  { n: "16", label: "TrustRadius products" },
];

const tiers = [
  { t: "A", cut: "≥ 60", note: "Top seller-priority expansion accounts" },
  { t: "B", cut: "≥ 45", note: "Strong expansion candidates" },
  { t: "C", cut: "≥ 35", note: "Nurture — partial footprint or fit" },
  { t: "D", cut: "≥ 15", note: "Low priority" },
  { t: "F", cut: "< 15", note: "Out of profile" },
  { t: "DQ", cut: "< 1,000 emp.", note: "Below enterprise floor" },
];

type Pillar = {
  name: string;
  weight: string;
  pts: string;
  question: string;
  accent: string;
  dims: { name: string; cap: string; detail: React.ReactNode; tag?: "PRIMARY" | "SECONDARY" }[];
  foot: React.ReactNode;
  footTone?: "info" | "warn";
};

const pillars: Pillar[] = [
  {
    name: "Fit",
    weight: "40%",
    pts: "100 pts",
    question: "Is this the right company?",
    accent: "bg-primary",
    dims: [
      { name: "Company Size", cap: "30", detail: "Employee count & revenue, bell-curved to Agentforce's large-enterprise, high-interaction sweet spot." },
      { name: "Industry Fit", cap: "30", detail: "NAICS tiering of the six high-interaction, data-rich verticals (financial services, telecom, technology, retail/consumer, travel/hospitality, healthcare & life sciences)." },
      { name: "Complexity Signals", cap: "25", detail: "Regulation, multi-national operations, brand scale, and IT intensity — the conditions that make governed, auditable agents a board-level requirement." },
      { name: "IT Spend (Bonus)", cap: "15", detail: "Budget capacity and share of spend in CRM / analytics / transformation categories. Not penalized when spend data is absent." },
    ],
    foot: "Hard disqualifier · employees < 1,000 (below the Agentforce enterprise floor).",
    footTone: "warn",
  },
  {
    name: "Need",
    weight: "45%",
    pts: "80 pts",
    question: "Does their stack show expansion readiness?",
    accent: "bg-emerald-600",
    dims: [
      {
        name: "Salesforce Footprint (Landing Zone)",
        cap: "30",
        tag: "PRIMARY",
        detail: (
          <>
            Depth of the existing Salesforce estate — the warmest expansion signal. Data 360 is the strongest grounding predictor;
            Marketing Cloud & Pardot broaden the base beyond core CRM.
            <br />
            <span className="font-medium text-destructive">
              Net-new guard: any Salesforce Agentforce SKU installed = −30
            </span>{" "}
            — an existing Agentforce customer is not net-new (backstop to the audience filter).
          </>
        ),
      },
      { name: "Demand & Grounding Signals", cap: "20", detail: "Warehouse / lakehouse (Snowflake, Databricks) for zero-copy grounding, and contact-center volume (Genesys) for a deflection ROI story." },
      { name: "Stack Momentum", cap: "15", detail: "Recent Salesforce / AI / data installs signal an active buying cycle; recent competitor-agent investments apply a negative timing penalty." },
      { name: "Competitor Displacement", cap: "15", tag: "SECONDARY", detail: "Copilot / ServiceNow / UiPath / chatbot tooling among Salesforce customers = an \"expand + consolidate\" booster — migrate competitor workloads onto the CRM-grounded platform." },
    ],
    foot: "EXPANSION-LED · footprint depth is the primary driver; competitor displacement is a secondary consolidation booster (down-weighted from 30 → 15 vs. the prior balanced model).",
    footTone: "info",
  },
  {
    name: "Intent",
    weight: "15%",
    pts: "100 pts",
    question: "Are they actively researching?",
    accent: "bg-accent",
    dims: [
      { name: "AI & Customer-Service Category", cap: "35", detail: "Category-level research Agentforce addresses without naming Salesforce — conversational AI, customer-service automation, deflection." },
      { name: "Salesforce AI Product Intent", cap: "30", detail: "Research on Salesforce's own AI line (AI Cloud, Einstein) — the nearest available proxy for direct Agentforce intent." },
      { name: "Competitor Intent", cap: "20", detail: "Research on competitor agent / service platforms means the account is in-market for the category." },
      { name: "Buyer Activity (TrustRadius)", cap: "15", detail: "Pricing, comparison, and review activity on Agentforce and competitor product pages — active-evaluation signal." },
    ],
    foot: "Proxy note · HG has no dedicated \"Agentforce\" / \"agentic AI\" intent topic, so Intent is built from the nearest Salesforce-AI and category signals and weighted accordingly (15%).",
    footTone: "warn",
  },
];

const decisions = [
  { k: "Population & membership gates", h: "Existing Salesforce, no Agentforce", why: "Both hard rules — must own Salesforce, must not run any Agentforce SKU — are enforced in the audience build against live HG install data, then the model ranks what qualifies." },
  { k: "Why membership lives upstream", h: "Validated at 30 accounts", why: "A hard in-model footprint disqualifier false-DQ'd ~30% of confirmed Salesforce customers, because the scoring engine's install lookup is less complete than the source catalog. Membership is enforced where install data is complete; the model never gates on it." },
  { k: "Net-new guard", h: "Any Agentforce SKU = −30", why: "A backstop: if an Agentforce customer slips past the audience filter, the guard zeroes its footprint credit and demotes it rather than ranking it as a prospect." },
  { k: "Expansion-led Need", h: "Footprint over displacement", why: "Footprint depth (30) is the primary driver; competitor displacement was demoted to a secondary consolidation booster (15). Need leads the composite at 45%." },
  { k: "Geography", h: "Favored, not filtered", why: "NA / UK & W. Europe / ANZ / Japan are favored through the Fit dimension. No hard geographic disqualifier." },
  { k: "Size floor", h: "Enterprise threshold", why: "Accounts under 1,000 employees are disqualified — below the Agentforce enterprise floor for interaction volume and budget capacity." },
];

const dataSources = [
  { h: "HG Firmographics", d: "Employees, revenue, multi-national footprint, Fortune / Forbes rank." },
  { h: "HG NAICS Industry Codes", d: "Vertical tiering and regulated-industry flags." },
  { h: "HG Technographics", d: "Salesforce footprint, competitor, grounding & contact-center install signals." },
  { h: "HG Intent", d: "18 topics across Salesforce-AI, category, and competitor research." },
  { h: "TrustRadius Buyer Activity", d: "16 products — pricing, comparison, and review activity." },
  { h: "HG IT & Spend Estimates", d: "IT budget, spend intensity, and CRM / analytics spend share." },
];

function tierClasses(t: string) {
  switch (t) {
    case "A": return "bg-emerald-500/15 text-emerald-700 border-emerald-500/40";
    case "B": return "bg-primary/15 text-primary border-primary/40";
    case "C": return "bg-amber-500/15 text-amber-700 border-amber-500/40";
    case "D": return "bg-accent/15 text-accent border-accent/40";
    case "F": return "bg-muted text-muted-foreground border-border";
    default: return "bg-destructive/15 text-destructive border-destructive/40";
  }
}

function Methodology() {
  return (
    <SectionContainer>
      <div className="space-y-14">
        {/* Hero / Model Overview */}
        <section>
          <div className="text-[11px] font-mono uppercase tracking-[0.2em] text-accent">
            Model Overview
          </div>
          <h2 className="mt-3 font-serif text-3xl leading-tight text-foreground">
            Fit · Need · Intent Scoring Model
          </h2>
          <p className="mt-4 text-sm text-muted-foreground">
            We found that less than 7% of the accounts you gave us have Agentforce. This
            scoring model identifies <b className="text-foreground">expansion opportunities inside the existing Salesforce customer base</b> —
            accounts already on Salesforce that are <b className="text-foreground">not yet running Agentforce</b> — and ranks them
            by propensity to adopt Salesforce Agentforce.
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 font-mono text-[11px] text-muted-foreground">
            MODEL <b className="text-accent">salesforce / agentforce</b> · version 27 · July 23, 2026
          </div>

          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {stats.map((s) => (
              <div key={s.label} className="rounded-md border border-border bg-card p-3">
                <div className="font-mono text-xl font-bold tabular-nums text-foreground">{s.n}</div>
                <div className="mt-1 text-[10.5px] leading-tight text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Scope / Population */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Model Scope & Population</h3>
            <span className="text-xs text-muted-foreground">membership is enforced upstream — the model ranks</span>
          </div>
          <div className="rounded-lg border border-emerald-500/30 border-l-4 border-l-emerald-600 bg-emerald-500/5 p-5">
            <h4 className="font-serif text-lg text-foreground">Existing Salesforce customers, not on Agentforce</h4>
            <p className="mt-2 text-sm text-muted-foreground">
              Membership is defined by two hard rules,{" "}
              <b className="text-foreground">enforced at the audience / list-build layer against live HG install data</b> — not
              inside the model. The model's job is to <b className="text-foreground">rank</b> the qualified population. (See{" "}
              <i>Design Decisions</i> for why membership lives upstream.)
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs font-semibold">
              <span className="rounded-md border border-border bg-card px-3 py-1.5 text-foreground">HG universe</span>
              <span className="text-muted-foreground">→</span>
              <span className="rounded-md border border-emerald-500/40 bg-card px-3 py-1.5 text-emerald-700">
                ✓ Has Salesforce / MuleSoft install
              </span>
              <span className="text-muted-foreground">→</span>
              <span className="rounded-md border border-destructive/40 bg-card px-3 py-1.5 text-destructive">
                ✗ Exclude any Salesforce Agentforce SKU
              </span>
              <span className="text-muted-foreground">→</span>
              <span className="rounded-md border border-primary/40 bg-card px-3 py-1.5 text-primary">
                Model ranks: Fit · Need · Intent
              </span>
            </div>
          </div>
        </section>

        {/* Composite & Tiers */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Composite & Tiers</h3>
            <span className="text-xs text-muted-foreground">need-led weighting</span>
          </div>
          <div className="flex h-12 overflow-hidden rounded-lg border border-border font-mono text-sm text-white">
            <span className="flex items-center justify-center bg-primary" style={{ flex: 40 }}>
              Fit 40%
            </span>
            <span className="flex items-center justify-center bg-emerald-600" style={{ flex: 45 }}>
              Need 45%
            </span>
            <span className="flex items-center justify-center bg-accent" style={{ flex: 15 }}>
              Intent 15%
            </span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Among accounts that already own Salesforce,{" "}
            <b className="text-foreground">stack signals — footprint depth and grounding readiness — are the sharpest predictor of
            Agentforce expansion</b>, so Need leads the composite. Fit confirms the company profile; Intent is a supporting proxy signal.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {tiers.map((t) => (
              <div key={t.t} className={`rounded-md border p-3 text-center ${tierClasses(t.t)}`}>
                <div className="font-mono text-lg font-bold">{t.t}</div>
                <div className="mt-0.5 text-[11px] opacity-80">{t.cut}</div>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs italic text-muted-foreground">
            A / B tiers are the seller-priority set. DQ applies only to the firmographic floor (employees &lt; 1,000);
            membership DQs (non-Salesforce, or Agentforce-installed) are handled by the audience filter above.
          </p>
        </section>

        {/* Pillars */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Dimensions by Pillar</h3>
            <span className="text-xs text-muted-foreground">caps shown per dimension</span>
          </div>
          <div className="grid gap-4 lg:grid-cols-3">
            {pillars.map((p) => (
              <div key={p.name} className="rounded-lg border border-border bg-card p-5">
                <div className={`-mx-5 -mt-5 mb-4 h-1 ${p.accent} rounded-t-lg`} />
                <div className="flex items-baseline justify-between">
                  <h4 className="font-serif text-lg text-foreground">{p.name}</h4>
                  <span className="font-mono text-xs text-muted-foreground">{p.weight} · {p.pts}</span>
                </div>
                <div className="mt-1 text-xs italic text-muted-foreground">{p.question}</div>
                <div className="mt-3 divide-y divide-border">
                  {p.dims.map((d) => (
                    <div key={d.name} className="py-3">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="text-sm font-medium text-foreground">
                          {d.name}
                          {d.tag ? (
                            <span
                              className={`ml-2 inline-block rounded px-1.5 py-0.5 align-middle font-mono text-[9.5px] font-bold text-white ${
                                d.tag === "PRIMARY" ? "bg-emerald-600" : "bg-muted-foreground"
                              }`}
                            >
                              {d.tag}
                            </span>
                          ) : null}
                        </span>
                        <span className="font-mono text-[10.5px] text-muted-foreground">{d.cap}</span>
                      </div>
                      <p className="mt-1 text-xs text-muted-foreground">{d.detail}</p>
                    </div>
                  ))}
                </div>
                <div
                  className={`mt-3 rounded-md border px-3 py-2 text-[11.5px] font-medium ${
                    p.footTone === "warn"
                      ? "border-amber-500/30 bg-amber-500/10 text-amber-700"
                      : "border-emerald-500/30 bg-emerald-500/10 text-emerald-700"
                  }`}
                >
                  {p.foot}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Design decisions */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Design Decisions</h3>
            <span className="text-xs text-muted-foreground">the choices that shaped this build</span>
          </div>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {decisions.map((d) => (
              <div key={d.k} className="rounded-md border border-border border-l-[3px] border-l-accent bg-card p-4">
                <div className="font-mono text-[10px] uppercase tracking-[0.12em] text-accent">{d.k}</div>
                <div className="mt-1 text-sm font-semibold text-foreground">{d.h}</div>
                <div className="mt-1 text-xs text-muted-foreground">{d.why}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Data Sources */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Data Sources</h3>
            <span className="text-xs text-muted-foreground">every signal comes from a live HG catalog</span>
          </div>
          <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
            {dataSources.map((s) => (
              <div key={s.h} className="rounded-lg border border-border bg-card p-4">
                <div className="text-sm font-semibold text-foreground">{s.h}</div>
                <p className="mt-1 text-xs text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-xs italic text-muted-foreground">
            Membership filtering (Salesforce-present, Agentforce-absent) runs against the HG install catalog, which is the
            authoritative source for install presence.
          </p>
        </section>

        {/* Scoring Results — placeholder tier structure */}
        <section>
          <div className="mb-4 flex items-baseline gap-3 border-b border-border pb-2">
            <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-accent">Scoring Results</h3>
            <span className="text-xs text-muted-foreground">tier structure</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Tier definitions applied to the pre-filtered expansion population.
          </p>
          <div className="mt-4 overflow-hidden rounded-md border border-border">
            <table className="w-full text-sm">
              <thead className="bg-secondary/50 text-left font-mono text-[10.5px] uppercase tracking-[0.1em] text-muted-foreground">
                <tr>
                  <th className="px-4 py-2">Tier</th>
                  <th className="px-4 py-2">Threshold</th>
                  <th className="px-4 py-2">Interpretation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {tiers.map((t) => (
                  <tr key={t.t}>
                    <td className="px-4 py-2">
                      <span
                        className={`inline-flex min-w-[2.5rem] justify-center rounded-full border px-2 py-0.5 font-mono text-xs ${tierClasses(t.t)}`}
                      >
                        {t.t}
                      </span>
                    </td>
                    <td className="px-4 py-2 font-mono tabular-nums text-foreground">{t.cut}</td>
                    <td className="px-4 py-2 text-muted-foreground">{t.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Methodology notes */}
        <div className="border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
          <p>
            Each account receives a 0–100 score per pillar; pillars are combined as Fit 40% / Need 45% / Intent 15% into a
            composite that maps to a tier. Dimension scores are capped, and the Salesforce Footprint dimension can go negative
            when the net-new guard fires.
          </p>
          <p className="mt-2">
            All firmographic, technographic, intent, and spend signals are sourced from live HG Insights catalogs; buyer-activity
            signals are sourced from TrustRadius. Membership (Salesforce-present, Agentforce-absent) is resolved against the HG
            install catalog, which is more complete than the scoring engine's install resolution — an accuracy gap flagged to the
            scoring pipeline so footprint-based <i>ranking</i> reaches the same completeness as membership filtering.
          </p>
        </div>
      </div>
    </SectionContainer>
  );
}
