import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { PageHeader, SectionContainer } from "@/components/section-page";

export const Route = createFileRoute("/data-demo")({
  head: () => ({
    meta: [
      { title: "Data Demo — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "Example account intelligence brief showing how HG data points come together on a single Salesforce account.",
      },
      { property: "og:title", content: "Data Demo — HG Insights for Salesforce" },
      {
        property: "og:description",
        content:
          "An illustrative brief on NOV Inc. using HG Time Series, FAI, GenAI, AI Spend, and Contacts data.",
      },
    ],
  }),
  component: DataDemo,
});

function DataDemo() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(1800);

  useEffect(() => {
    const iframe = iframeRef.current;
    if (!iframe) return;

    const resize = () => {
      const doc = iframe.contentDocument;
      if (!doc) return;
      const h = Math.max(
        doc.documentElement.scrollHeight,
        doc.body?.scrollHeight ?? 0,
      );
      if (h > 0) setHeight(h);
    };

    const onLoad = () => {
      resize();
      const doc = iframe.contentDocument;
      if (!doc) return;
      const ro = new ResizeObserver(resize);
      ro.observe(doc.documentElement);
      if (doc.body) ro.observe(doc.body);
      (iframe as any)._ro = ro;
    };

    iframe.addEventListener("load", onLoad);
    if (iframe.contentDocument?.readyState === "complete") onLoad();

    return () => {
      iframe.removeEventListener("load", onLoad);
      (iframe as any)._ro?.disconnect();
    };
  }, []);

  return (
    <div>
      <PageHeader
        eyebrow="Part 2"
        title="Data Demo — Beyond the Ask"
        description={`Purpose of this page: demonstrate how HG's broader data points, like Time Series technology install trends, Buying Centers aka Functional Area Intelligence, Generative AI Maturity signals, AI Spend, and Contacts, come together on a single Salesforce expansion opp. Below is an AI-focused account brief for NOV Inc., a longtime Salesforce Sales Cloud customer with great potential to expand with Agentforce. It uses real HG data, nothing fabricated.`}
      />
      <SectionContainer>
        <div className="overflow-hidden rounded-lg border border-border bg-card">
          <iframe
            ref={iframeRef}
            src="/demos/nov-data-demo.html"
            title="NOV Inc. — HG Data Demo"
            scrolling="no"
            className="block w-full"
            style={{ height: `${height}px`, border: 0 }}
          />
        </div>
      </SectionContainer>
    </div>
  );
}
