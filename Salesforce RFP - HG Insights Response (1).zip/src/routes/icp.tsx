import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PageHeader, SubNav } from "@/components/section-page";

const subNav = [
  { to: "/icp/summary", label: "ICP Summary" },
  { to: "/icp/methodology", label: "Scoring Model Summary" },
  { to: "/icp/scored-accounts", label: "Scored Accounts" },
  { to: "/icp/account-brief", label: "Account Briefs for Sellers" },
];

export const Route = createFileRoute("/icp")({
  head: () => ({
    meta: [
      { title: "ICP, Scoring Model, & Account Briefs — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "A defensible ICP and scoring model selected for Agentforce and applied to Salesforce's provided account list to unlock the best fit accounts to target.",
      },
      { property: "og:title", content: "ICP, Scoring Model, & Account Briefs — HG Insights for Salesforce" },
      {
        property: "og:description",
        content:
          "50 scored accounts, ICP methodology, and one-page briefs written for Salesforce AEs.",
      },
    ],
  }),
  component: () => (
    <div>
      <PageHeader
        eyebrow="Part 3"
        title="ICP, Scoring Model, & Account Briefs"
        description={
          <>
            <p>1 defensible ICP and&nbsp;scoring model for Agentforce and applied to Salesforce's provided account list to unlock some of the best fit accounts to target.</p>
            <p className="mt-2">20 accounts scored and tiered for seller prioritization.</p>
            <p className="mt-2">1 Account Brief written for a Salesforce AE to know exactly what opps to win with named contacts.</p>
          </>
        }
      />
      <SubNav items={subNav} />
      <Outlet />
    </div>
  ),
});
