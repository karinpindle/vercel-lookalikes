import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Database, LineChart, Target } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HG Insights Response to Salesforce RFP" },
      {
        name: "description",
        content:
          "Executive overview of HG Insights' response to the Salesforce RFP, including enriched accounts, crosswalks, and ICP scoring.",
      },
    ],
  }),
  component: Landing,
});

const kpis = [
  { label: "Accounts matched to HG graph", value: "96%", sub: "of ~50,000 accounts" },
  { label: "TECHNOLOGIES EXACT-MATCHED", value: "90%", sub: "of ~2,400 technologies · +8,294 recommended" },
  { label: "INTENT TOPICS EXACT-MATCHED", value: "26%", sub: "of ~8,000 keywords · +1,031 recommended" },
  { label: "AGENTFORCE ICP ACCOUNTS SCORED", value: "20", sub: "with sample account briefs" },
];


const sections = [
  {
    to: "/rfp-response" as const,
    icon: Database,
    eyebrow: "Part 1",
    title: "RFP Response",
    description:
      "The formal deliverables aligned line-by-line to what Salesforce requested: enriched accounts, products & technologies crosswalk, and intent topics crosswalk — each with our recommended additions.",
    links: [
      { to: "/rfp-response" as const, label: "Summary" },
    ],
  },
  {
    to: "/data-demo" as const,
    icon: LineChart,
    eyebrow: "Part 2",
    title: "Data Demo — Beyond the Ask",
    description:
      "You asked for technographics and intent but we go much deeper with our intelligence. To demonstrate how and why it's valuable, we created a real-life account intelligence brief with our deeper technographics including Time Series installs, Functional Area Intelligence, and we added in our Generative AI Maturity signals, AI Spend, and Contacts.",
    links: [
      { to: "/data-demo" as const, label: "View sample Account Brief" },
    ],
  },
  {
    to: "/icp" as const,
    icon: Target,
    eyebrow: "Part 3",
    title: "ICP Scoring & Account Briefs",
    description:
      "A defensible ICP model applied to the account list, delivering 20 ranked accounts with tiering, key signals, and per-account briefs to hand directly to sales.",
    links: [
      { to: "/icp" as const, label: "ICP for Agentforce with Scoring Model" },
      { to: "/icp/methodology" as const, label: "Sample of Scored Accounts with Account Briefs" },
    ],
  },
];

function Landing() {
  return (
    <div>
      <section className="bg-primary text-primary-foreground">
        <div className="mx-auto max-w-7xl px-6 py-16 sm:py-24">
          <div className="text-sm font-semibold uppercase tracking-[0.24em] text-primary-foreground">
            Confidential · Prepared for Salesforce
          </div>
          <h1 className="mt-4 font-serif text-4xl leading-tight sm:text-5xl md:text-6xl">
            HG Insights' response to Salesforce's RFP
          </h1>
          <p className="mt-6 text-base text-primary-foreground/80 sm:text-lg">
            A single place for Salesforce's&nbsp;FY27 Intent & Technographics Vendor Assessment&nbsp;team to review our enriched account list,
            product and intent crosswalks, extended data demonstrations, and a scored ICP with
            ready-to-use account briefs.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/rfp-response"
              className="inline-flex items-center gap-2 rounded-md bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-colors hover:bg-accent/90"
            >
              Review RFP response <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/icp"
              className="inline-flex items-center gap-2 rounded-md border border-primary-foreground/30 px-5 py-2.5 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-foreground/10"
            >
              Jump to ICP <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      <section className="border-b border-border bg-card">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px overflow-hidden bg-border md:grid-cols-4">
          {kpis.map((k) => (
            <div key={k.label} className="bg-card px-6 py-8">
              <div className="font-serif text-3xl text-primary">{k.value}</div>
              <div className="mt-1 text-xs uppercase tracking-[0.14em] text-muted-foreground">
                {k.label}
              </div>
              <div className="mt-1 text-xs text-muted-foreground/80">{k.sub}</div>
            </div>
          ))}

        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16">
        <div className="mb-10">
          <div className="text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            How this response is organized
          </div>
          <h2 className="mt-2 font-serif text-3xl text-foreground">Three parts</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Start with the formal RFP deliverables, then explore the additional HG datasets that
            extend the ask, and finish with a scored Agentforce ICP and briefs applied directly to the
            Salesforce account list.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {sections.map((s) => {
            const Icon = s.icon;
            return (
              <Link
                key={s.to}
                to={s.to}
                className="group flex flex-col rounded-lg border border-border bg-card p-6 transition-all hover:border-accent hover:shadow-md"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-primary text-primary-foreground">
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                    {s.eyebrow}
                  </div>
                </div>
                <h3 className="mt-4 font-serif text-2xl text-foreground">{s.title}</h3>
                <p className="mt-3 flex-1 text-sm text-muted-foreground">{s.description}</p>
                <ul className="mt-5 space-y-1.5 border-t border-border pt-4 text-sm">
                  {s.links.map((l) => (
                    <li key={l.to} className="flex items-center gap-2 text-foreground/80">
                      <span className="h-1 w-1 rounded-full bg-accent" />
                      {l.label}
                    </li>
                  ))}
                </ul>
                <div className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-primary group-hover:gap-2 transition-all">
                  Open section <ArrowRight className="h-4 w-4" />
                </div>
              </Link>
            );
          })}
        </div>
      </section>

    </div>
  );
}
