import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PageHeader } from "@/components/section-page";


export const Route = createFileRoute("/rfp-response")({
  head: () => ({
    meta: [
      { title: "RFP Response — HG Insights for Salesforce" },
      {
        name: "description",
        content:
          "Enriched accounts, product and technology crosswalks, and intent topic crosswalks — HG Insights' formal RFP deliverables for Salesforce.",
      },
      { property: "og:title", content: "RFP Response — HG Insights for Salesforce" },
      {
        property: "og:description",
        content:
          "Formal HG Insights deliverables aligned to Salesforce's RFP: accounts, products, intent.",
      },
    ],
  }),
  component: RfpLayout,
});

function RfpLayout() {
  return (
    <div>
      <PageHeader
        eyebrow="Part 1"
        title="RFP Response Summary"
        description="The formal deliverables aligned line-by-line to Salesforce's request: Enriched Account lists, a Technologies Taxonomy Crosswalk with recommended additions, and an Intent Topics Crosswalk with recommended additions."
      />
      
      <Outlet />
    </div>
  );
}
