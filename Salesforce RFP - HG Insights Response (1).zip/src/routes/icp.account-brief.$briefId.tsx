import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { useRef, useState } from "react";

const briefs: Record<string, { title: string; file: string }> = {
  primerica: {
    title: "Primerica, Inc.",
    file: "/briefs/primerica.html",
  },
  celcom: {
    title: "Celcom Berhad (CelcomDigi)",
    file: "/briefs/celcom.html",
  },
};


export const Route = createFileRoute("/icp/account-brief/$briefId")({
  head: ({ params }) => {
    const b = briefs[params.briefId];
    return {
      meta: [
        {
          title: b
            ? `Account Brief — ${b.title} | HG Insights for Salesforce`
            : "Account Brief — HG Insights",
        },
        {
          name: "description",
          content: b
            ? `Sample one-page Salesforce Agentforce Account Brief for ${b.title}.`
            : "Account brief not found.",
        },
      ],
    };
  },
  loader: ({ params }) => {
    if (!briefs[params.briefId]) throw notFound();
    return briefs[params.briefId];
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <BackLink />
      <p className="mt-6 text-sm text-muted-foreground">Brief not found.</p>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-7xl px-6 py-10">
      <BackLink />
      <p className="mt-6 text-sm text-destructive">{error.message}</p>
    </div>
  ),
  component: BriefPage,
});

function BackLink() {
  return (
    <Link
      to="/icp/account-brief"
      className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
    >
      <ArrowLeft className="h-4 w-4" /> Back to Account Briefs
    </Link>
  );
}

function BriefPage() {
  const brief = Route.useLoaderData();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [height, setHeight] = useState(1200);

  const handleLoad = () => {
    const iframe = iframeRef.current;
    if (!iframe?.contentWindow) return;
    const doc = iframe.contentWindow.document;
    const measure = () => {
      const h = Math.max(
        doc.body.scrollHeight,
        doc.documentElement.scrollHeight,
      );
      setHeight(h);
    };
    measure();
    const RO = (iframe.contentWindow as unknown as { ResizeObserver: typeof ResizeObserver }).ResizeObserver;
    const ro = new RO(measure);
    ro.observe(doc.body);
  };

  return (
    <div>
      <div className="mx-auto max-w-7xl px-6 pt-6">
        <BackLink />
      </div>
      <div className="mx-auto max-w-7xl px-6 py-6">
        <iframe
          ref={iframeRef}
          src={brief.file}
          title={`Account Brief — ${brief.title}`}
          scrolling="no"
          onLoad={handleLoad}
          style={{ height: `${height}px` }}
          className="w-full rounded-lg border border-border bg-white shadow-sm"
        />
      </div>
    </div>
  );
}
