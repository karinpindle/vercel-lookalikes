import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import hgLogoWhite from "../assets/hg-logo-white.svg";

const nav = [
  { to: "/", label: "Overview" },
  { to: "/rfp-response", label: "RFP Response" },
  { to: "/data-demo", label: "Data Demo" },
  { to: "/icp", label: "ICP & Briefs" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const isActive = (to: string) =>
    to === "/" ? pathname === "/" : pathname === to || pathname.startsWith(to + "/");

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-40 border-b border-border bg-primary text-primary-foreground">
        <div className="relative mx-auto flex h-16 max-w-7xl items-center justify-center px-6">
          <Link to="/" className="absolute left-6 flex items-center gap-3">
            <img
              src={hgLogoWhite}
              alt="HG Insights"
              className="h-7 w-auto"
            />
            <span className="hidden h-6 w-px bg-primary-foreground/25 sm:block" />
            <div className="hidden leading-tight sm:block">
              <div className="text-[10px] uppercase tracking-[0.18em] text-primary-foreground/70">
                Response for Salesforce
              </div>
              <div className="font-serif text-xs text-primary-foreground/90">
                RFP · 2026
              </div>
            </div>
          </Link>
          <nav className="flex flex-wrap items-center justify-center gap-1">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className={
                  "rounded-md px-3 py-1.5 text-sm transition-colors " +
                  (isActive(item.to)
                    ? "bg-accent text-accent-foreground font-medium"
                    : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground")
                }
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>


      <main className="flex-1">{children}</main>

      <footer className="border-t border-border bg-primary text-primary-foreground/70">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-2 px-6 py-6 text-xs sm:flex-row sm:items-center">
          <div>© {new Date().getFullYear()} HG Insights. Prepared for Salesforce evaluation.</div>
          <div className="font-mono">Confidential — RFP Response · July 2026</div>
        </div>
      </footer>
    </div>
  );
}
