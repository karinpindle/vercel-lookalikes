import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";

export function PageHeader({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="border-b border-border bg-secondary/40">
      <div className="mx-auto max-w-7xl px-6 py-10">
        {eyebrow ? (
          <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
            {eyebrow}
          </div>
        ) : null}
        <h1 className="font-serif text-3xl text-foreground sm:text-4xl">{title}</h1>
        {description ? (
          <div className="mt-3 text-sm text-muted-foreground sm:text-base">
            {description}
          </div>
        ) : null}
        {children ? <div className="mt-6">{children}</div> : null}
      </div>
    </div>
  );
}

export function SectionContainer({ children }: { children: ReactNode }) {
  return <div className="mx-auto max-w-7xl px-6 py-10">{children}</div>;
}

export function SubNav({
  items,
}: {
  items: { to: string; label: string; params?: Record<string, string> }[];
}) {
  return (
    <div className="mx-auto max-w-7xl px-6">
      <div className="flex flex-wrap gap-1 border-b border-border">
        {items.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            activeOptions={{ exact: true }}
            activeProps={{
              className:
                "border-accent text-foreground font-medium",
            }}
            inactiveProps={{
              className: "border-transparent text-muted-foreground hover:text-foreground",
            }}
            className="border-b-2 px-4 py-3 text-sm transition-colors"
          >
            {item.label}
          </Link>
        ))}
      </div>
    </div>
  );
}

export function ComingSoon({ note }: { note?: string }) {
  return (
    <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center">
      <div className="mx-auto max-w-md">
        <div className="mb-2 text-[11px] uppercase tracking-[0.2em] text-accent">
          Awaiting source data
        </div>
        <h3 className="font-serif text-xl text-foreground">Content lands here</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          {note ??
            "This view is scaffolded and will populate once the corresponding data file is provided."}
        </p>
      </div>
    </div>
  );
}
