
# HG × Salesforce RFP Response App — Plan

A polished, corporate-toned web app that packages HG Insights' response to Salesforce's RFP. Executive landing page with cards linking into three deep-dive sections, filterable tables/charts throughout, and a dedicated ICP scoring methodology page.

Files will be provided later; this plan defines the layout and routing shell so we can drop in real data (accounts, crosswalks, briefs) as it arrives.

## Route Structure

```text
/                          Landing — exec summary, 3 section cards, KPIs
/rfp-response              Part 1: RFP Response
  ├─ /rfp-response/accounts        Enriched ~48k accounts (filterable table)
  ├─ /rfp-response/products        Products/Technologies crosswalk + recommended
  └─ /rfp-response/intent          Intent topics crosswalk + recommended
/data-demo                 Part 2: Beyond-RFP data demo hub
  ├─ /data-demo/time-series
  ├─ /data-demo/fai                Functional Area Intelligence
  ├─ /data-demo/genai
  ├─ /data-demo/ai-spend
  └─ /data-demo/contacts
/icp                       Part 3: ICP hub — 50 scored accounts table
  ├─ /icp/methodology              Scoring model, weights, inputs
  └─ /icp/account/$accountId       Account Brief detail page
```

Every route gets its own `head()` with route-specific title, description, and og tags. Root `__root.tsx` hosts the shared shell (top nav + HG-branded header + footer); no og:image at root.

## Landing Page (`/`)

- Header band: "HG Insights response to Salesforce RFP" + subtitle, date, primary CTAs (Download response, Jump to ICP).
- KPI strip: accounts enriched (~48k), products crosswalked, intent topics mapped, ICP accounts scored (50).
- Three large section cards linking to `/rfp-response`, `/data-demo`, `/icp`, each with a one-line value prop and 2–3 sub-links.
- Short "How to navigate this response" note for the Salesforce eval committee.

## Part 1 — RFP Response (`/rfp-response`)

Section landing with a summary of what Salesforce requested vs. what we delivered, plus three sub-route cards.

- **Accounts (`/accounts`)** — Filterable table over the ~48k enriched accounts. Filters: industry, employee band, revenue band, country, HQ state, tech installed (chip filter), intent level. Column chooser, CSV export, pagination via URL search params. Charts above the table: distribution by industry, employee band, and geography.
- **Products crosswalk (`/products`)** — Table mapping Salesforce's requested products/categories → HG products/vendors + recommended additions column, with source/coverage notes. Filter by category, "recommended" toggle.
- **Intent (`/intent`)** — Same shape for intent topics: requested → HG-mapped → recommended additions, with brief rationale per row.

All three read from static JSON bundled with the app (populated once files arrive). Tables use TanStack Query + URL search params for filter/sort/page state.

## Part 2 — Data Demo (`/data-demo`)

Hub page framing this as "what HG offers beyond the RFP ask." Each sub-route is a focused showcase with a short explainer, sample chart, and sample table pulled from provided demo data:

- Time Series: install trend charts for a handful of anchor products.
- FAI: department-level headcount/skills view for a sample of accounts.
- GenAI: GenAI intent + AI maturity scores across a sample set.
- AI Spend: estimated AI-related spend by category (if data provided).
- Contacts: sample enriched contacts tied to a few accounts.

All charts client-side (Recharts). Same filterable-table pattern as Part 1.

## Part 3 — ICP (`/icp`)

- **Hub** — Ranked table of 50 scored accounts: rank, company, score, tier (A/B/C), key signals (chips), link to brief. Sortable, filterable by tier/industry/region.
- **Methodology (`/methodology`)** — Static page: inputs used (firmographic, technographic, intent, FAI, GenAI, AI spend), weights per signal, scoring formula, tier cutoffs, data sources. Presented as clean sections with a weights table.
- **Account Brief (`/account/$accountId`)** — Detail page per account: firmographics header, score breakdown by signal category, tech footprint, intent signals, recommended plays, contacts (if available), and a "why this account" narrative. Dynamic route driven by the same JSON that powers the ICP table.

## Design Direction

Polished, corporate, HG brand-forward. Since the audience is a Salesforce evaluation committee, we want restraint over flourish:

- Palette: Navy Trust (deep navy + crisp white + a single accent). Neutral surfaces, high-contrast type.
- Typography: `libre-baskerville-ibm-plex` — serif display for headers gives an evaluative/consultative tone, IBM Plex Sans for body/tables.
- Layout: sidebar navigation for deep-dive routes, full-width sections on the landing page. Data-dense but airy tables.
- No decorative animation; subtle transitions only.

## Technical Notes

- TanStack Start routing per the codebase conventions; every route gets `head()`, `errorComponent`, `notFoundComponent`.
- Data: static JSON in `src/data/` for accounts, crosswalks, ICP scores, briefs. Loaders use `ensureQueryData` + `useSuspenseQuery`.
- Filters/sort/page all stored in URL search params via `validateSearch` + `zodValidator` with `fallback(...)`.
- Tables: shadcn Table + TanStack Table for column defs; virtualization on the 48k-account table.
- Charts: Recharts.
- Sidebar: shadcn `Sidebar` with collapsible icon mode inside the deep-dive routes; landing page uses full-width layout without the sidebar.

## Build Order (once files arrive)

1. Root shell: nav, footer, brand tokens, landing page (with placeholder KPI numbers).
2. Route scaffolding for all sub-routes with empty states.
3. Wire in the accounts dataset + filterable table pattern; reuse across the other tables.
4. Products + intent crosswalks.
5. Data-demo sub-routes (one at a time as data lands).
6. ICP table, methodology page, dynamic account brief route.
7. Metadata polish (per-route `head()`, og tags), QA pass.

## Open Items (not blocking layout work)

- Final list of data-demo sub-sections you want visible for the committee (all five, or a subset?).
- Whether the ~48k account table should be searchable by company name (recommend yes).
- Any Salesforce-provided branding cues to echo (subtle) or strictly HG-only.
